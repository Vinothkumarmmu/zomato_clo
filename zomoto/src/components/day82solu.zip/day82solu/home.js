import React from "react";
import QuickSearch from "./quicksearch";
import Wallpaper from "./wallpaper";
import 'C:/Users/vinoth/vinoth/day82/zomoto/src/styles/style.css'


class Home extends React.Component {
    render() {
        return (

            <div>
                <Wallpaper/>
                {/* <br /> */}
                <QuickSearch/>
                
            </div>

        )
    }
}

export default Home;