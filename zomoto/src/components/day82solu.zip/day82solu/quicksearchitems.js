import React from "react";
// import Row from 'react-bootstrap/Row';
// import Col from 'react-bootstrap/Col';
// import Stack from 'react-bootstrap/Stack';
class QuickSearchItems extends React.Component {
    render() {
        return (
            <div>
                {/* <Row>
                        <Col md={4} lg={6} xl={3}>
                            
                        </Col>
                    </Row> */}
                
                {/* <div className="row d-flex justify"> */}
                <div className="col">
                    <div className="column col g-4 mx-3 col-md-4 col-lg-6 col-xl-3">
                        <img src={this.props.img} style={{ height: "100%", width: "150px" }} alt={"img not found"}/>
                        <h5 className="head1">{this.props.meals}</h5>
                        <p className="item1">
                            {this.props.describe}
                        </p>
                        
                    </div>
                </div>
                {/* </div> */}
                 
               
            </div>
        )
    }
}
export default QuickSearchItems;