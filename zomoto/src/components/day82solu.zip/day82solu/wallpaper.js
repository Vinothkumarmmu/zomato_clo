import React from "react";
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
// import Form from 'react-bootstrap/Form';
import 'C:/Users/vinoth/vinoth/day82/zomoto/node_modules/font-awesome/css/font-awesome.min.css'



class Wallpaper extends React.Component{
    render(){
        return(
            <div>
                <div id="img" className="img-fluid">
                    <div className="buttons">
                        <Button className="loginbutton btn" variant="primary">login</Button>
                        <Button className="createbutton btn" variant="primary">create an account</Button>
                    </div>
                    <div className="logo">
                        e!
                    </div>
                    <br />
                    <h1>Find the best restaurant, cafes, and bars</h1>
                    <br />
                    <div className="search" >
                        <Col xl={6} lg={4} md={6} sm={12}></Col>
                        <input type="text"  list="cities" placeholder="please type your location " />
                        {/* <Form.Select aria-label="Default select example"></Form.Select> */}
                        <datalist id="cities" >
                            <option>kerala</option>
                            <option>Bangalore </option>
                            <option>Chennai </option>
                            <option>Delhi </option>
                            <option>Kolkata </option>
                            <option>Mumbai </option>
                            <option>Coimbatore </option>
                        </datalist>
                        {/* <i class="fa-light fa-magnifying-glass"></i> */}

                         

                       


                        <input className="awesome fa-light fa-magnifying-glass"  type="text" placeholder="&#xf08e; Type a Restaruant " /> 
                         
                            


                    </div>
                </div>
            </div>
        )
    }
}
export default Wallpaper;