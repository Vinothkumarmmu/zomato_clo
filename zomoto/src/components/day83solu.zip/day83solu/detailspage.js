import React from "react";
import 'C:/Users/vinoth/vinoth/day82/zomoto/src/styles/detailspage.css';
import img6 from 'C:/Users/vinoth/vinoth/day82/zomoto/src/asserts/detail.jpg'
import img from 'C:/Users/vinoth/vinoth/day82/zomoto/src/asserts/South.jpg'
import img1 from  'C:/Users/vinoth/vinoth/day82/zomoto/src/asserts/india.jpg'
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import { Carousel } from "react-responsive-carousel";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";
class DetailsPage extends React.Component {
    render() {
        return (
            <div>
                <div className="contanier-fluid box1">
                    <Carousel>
                        <div>
                            <img src={(img6)} alt={"img not found"} className="img1" />
                        </div>
                        <div>
                            <img src={img} alt={"img not found"} className="img1" />
                        </div>
                        <div>
                            <img src={img1} alt={"img not found"} className="img1" />
                        </div>
                    </Carousel>

                    <h1 className="h1">The Big Chill Cakery</h1>
                    <button className="btn btn-danger bn">Place Online Order</button>
                    <Tabs className="tabs">
                        <TabList>
                            <Tab>Overview</Tab>
                            <Tab>Contact</Tab>
                        </TabList>
                        <TabPanel>
                            <h3>Overview:</h3>
                            <h6>Previous Next
                                View Larger Image
                                The restaurant industry is one of the largest components of the hospitality industry and is focused on providing food services where customers are able to order food and eat it on the premises</h6>
                        </TabPanel>
                        <TabPanel>
                            <h3>Phone number</h3>
                            <h6>+91 6379430500</h6>
                            <br />
                            <h3>The Big Chill Cakery</h3>
                            <h6>No.11 tulsi street velandipalayam</h6>
                        </TabPanel>
                    </Tabs>
                    <br/>
                </div>
                <br/><br/>

            </div>
        )
    }
}
export default DetailsPage;