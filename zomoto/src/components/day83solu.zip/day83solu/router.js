import React from "react";
import { Route,Routes } from "react-router-dom";
import Home from '../day82solu/home';
import FilterPage from "./filterpage";
import DetailsPage from "./detailspage";
class Router extends React.Component{
    render(){
        return(
            <div>
                <Routes>
                    <Route exact path="/" element={<Home/>}></Route>
                    <Route exact path="/home" element={<Home/>}></Route>
                    <Route exact path="/filter" element={<FilterPage/>}></Route>
                    <Route exact path="/details" element={<DetailsPage/>}></Route>
                </Routes>

            </div>
        )
    }
}
export default Router;