import React, { useState } from "react";
import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import 'C:/Users/vinoth/vinoth/day82/backend/zomoto/src/styles/filterpage.css';

const Header = () => {
    const [location, setLocation] = useState({
        backgroundColor: '',
        display: 'none'
    });
    const path = useLocation();
    
    console.log(path);


    const Background = () => {
        const pathway = path.pathname;
        let bg;
        let display;
        if (pathway == '/') {
            bg = '#ff0000';
            display = 'none';
        } else {
            bg = '#ff0000';
            display = 'inline-block';
        }
        setLocation({
            backgroundColor: bg,
            display: display
        });}

        useEffect(Background, []);

        // constructor(){
        //     super();
        //     this.state={
        //         backgroundColor:'',
        //         display:'none'
        //     }
        // }
        // componentDidMount(){
        //     const path=this.props.history.location.pathname;
        //     this.setBackground(path);
        // }

        // }

        // const{backgroundColor,display}=this.state;
        return (
            <div>
                <div className="container-fluid head" style={{backgroundColor:location.backgroundColor}}>
                    <div className="box" style={{display:location.display}}>e!</div>
                    <button className="btn btn-light mx-2">login</button>
                    <button className="btn btn-light">Create an Account</button>
                </div>
            </div>
            //  
            //  
        )
    }


export default Header;