import React, { useState } from "react";
import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import 'C:/Users/vinoth/vinoth/day82/backend/zomoto/src/styles/filterpage.css';
import Modal from 'react-modal';

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
    },
};

const Header = () => {
    let [IsOpen, setIsOpen] = useState(false);

  let handleLogin = () => {
        setIsOpen(true)
    }
    let handleCancel = () => {
        setIsOpen(false)
    }

    const [location, setLocation] = useState({
        backgroundColor: '',
        display: 'none'
    });
    const path = useLocation();

    console.log(path);


    const Background = () => {
        const pathway = path.pathname;
        let bg;
        let display;
        if (pathway == '/') {
            bg = '#ff0000';
            display = 'none';
        } else {
            bg = '#ff0000';
            display = 'inline-block';
        }
        setLocation({
            backgroundColor: bg,
            display: display
        });
    }

    useEffect(Background, []);

    // constructor(){
    //     super();
    //     this.state={
    //         backgroundColor:'',
    //         display:'none'
    //     }
    // }
    // componentDidMount(){
    //     const path=this.props.history.location.pathname;
    //     this.setBackground(path);
    // }

    // }

    // const{backgroundColor,display}=this.state;
    return (
        <div>
            <div className="container-fluid head" style={{ backgroundColor: location.backgroundColor }}>
                <div className="box" style={{ display: location.display }}>e!</div>
                <button className="btn btn-light mx-2" onClick={handleLogin}>login</button>
                <button className="btn btn-light">Create an Account</button>
            </div>

            <Modal isOpen={IsOpen} style={customStyles}>
                  <form style={{backgroundColor:"lightgray",border:"2px dashed black",padding:"20px",height:"450px",width:"250px"}}>
                    <div style={{display:"flex"}}>
                    <h2>Login</h2>
                    <button style={{color:"red",marginLeft:"50%",marginTop:"20px"}}>X</button>
                    </div>
                    <div style={{color:"blue"}} ><span>Email</span>
                        <input type="email" placeholder="Email" style={{borderRadius:"5px",color:"red"}} required/>
                        <span>Password</span>
                        <input type="password" placeholder="Password" style={{borderRadius:"5px",color:"red"}} required/>
                        <br/>
                        <div style={{display:"flex",justifyContent:"space-evenly"}}>
                        <button style={{backgroundColor:"sandybrown",borderRadius:"5px"}}>Submit</button>
                        <button style={{backgroundColor:"sandybrown",borderRadius:"5px"}} onClick={handleCancel}>Cancel</button>
                        </div>
                        <a href="#">Forget Password</a>
                        <br/>
                        <button style={{backgroundColor:"lightblue",borderRadius:"5px",marginLeft:"27px"}}>Create New Account</button>
                    </div>
                    <button style={{backgroundColor:"gray",borderRadius:"5px",marginLeft:"5px"} }><i class="bi bi-facebook"></i> Continue with Facebook</button>
                    <button style={{backgroundColor:"gray",borderRadius:"5px",marginLeft:"12px"} }><i class="bi bi-google"></i> Continue with Google</button>
                  </form>


            </Modal>
        </div>
        //  
        //  
    )

}


export default Header;